Hazel Interactive Website

Open index.html in a browser or upload it to GitHub Pages.
The photos are embedded in the HTML.
John is used as the sender name.
No em dashes are used in the messages.
The MP3 is optional and is not included.
